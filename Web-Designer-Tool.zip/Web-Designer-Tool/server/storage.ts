import { db } from "./db";
import {
  services,
  bookings,
  bookingItems,
  movies,
  reservations,
  type Service,
  type Booking,
  type CreateBookingRequest,
  type Movie,
  type Reservation,
  type CreateReservationRequest,
} from "@shared/schema";
import { eq, inArray } from "drizzle-orm";

export interface IStorage {
  getServices(): Promise<Service[]>;
  createBooking(booking: CreateBookingRequest): Promise<Booking>;
  seedServices(): Promise<void>;
  
  getMovies(): Promise<Movie[]>;
  createReservation(res: CreateReservationRequest): Promise<Reservation>;
  seedMovies(): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getServices(): Promise<Service[]> {
    return await db.select().from(services).orderBy(services.price);
  }

  async createBooking(req: CreateBookingRequest): Promise<Booking> {
    const selectedServices = await db
      .select()
      .from(services)
      .where(inArray(services.id, req.serviceIds));

    const totalAmount = selectedServices.reduce((sum, s) => sum + s.price, 0);

    const [booking] = await db
      .insert(bookings)
      .values({
        customerName: req.customerName,
        customerEmail: req.customerEmail,
        customerPhone: req.customerPhone,
        eventDate: new Date(req.eventDate),
        totalAmount: totalAmount,
        status: "confirmed",
      })
      .returning();

    if (req.serviceIds.length > 0) {
      await db.insert(bookingItems).values(
        selectedServices.map((s) => ({
          bookingId: booking.id,
          serviceId: s.id,
          priceAtBooking: s.price,
        }))
      );
    }

    return booking;
  }

  async getMovies(): Promise<Movie[]> {
    return await db.select().from(movies);
  }

  async createReservation(req: CreateReservationRequest): Promise<Reservation> {
    const [movie] = await db.select().from(movies).where(eq(movies.id, req.movieId));
    if (!movie) throw new Error("Movie not found");

    let totalAmount = movie.ticketPrice * req.ticketsCount;
    let discountApplied = false;

    if (req.ticketsCount >= 5) {
      totalAmount = Math.round(totalAmount * 0.8); // 20% discount
      discountApplied = true;
    }

    const [reservation] = await db
      .insert(reservations)
      .values({
        movieId: req.movieId,
        customerName: req.customerName,
        customerEmail: req.customerEmail,
        ticketsCount: req.ticketsCount,
        totalAmount: totalAmount,
        discountApplied: discountApplied,
      })
      .returning();

    return reservation;
  }

  async seedServices(): Promise<void> {
    const count = await db.select().from(services);
    if (count.length === 0) {
      await db.insert(services).values([
        {
          name: "Individual Portrait Session",
          description: "1-hour session, professional editing, 10 digital photos.",
          price: 15000,
          category: "Portrait",
          imageUrl: "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?auto=format&fit=crop&q=80&w=1000",
        },
        {
          name: "Wedding Photography Package",
          description: "Full day coverage (8 hours), 300+ edited photos, online gallery.",
          price: 120000,
          category: "Wedding",
          imageUrl: "https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&q=80&w=1000",
        },
        {
          name: "Event Coverage",
          description: "Corporate or private events, per hour rate (min 2 hours).",
          price: 10000,
          category: "Event",
          imageUrl: "https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&q=80&w=1000",
        },
      ]);
    }
  }

  async seedMovies(): Promise<void> {
    const count = await db.select().from(movies);
    if (count.length === 0) {
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      
      await db.insert(movies).values([
        {
          title: "Inception",
          description: "A thief who steals corporate secrets through the use of dream-sharing technology.",
          ticketPrice: 1200, // $12.00
          imageUrl: "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?auto=format&fit=crop&q=80&w=1000",
          showtime: tomorrow,
        },
        {
          title: "The Matrix",
          description: "A computer hacker learns from mysterious rebels about the true nature of his reality.",
          ticketPrice: 1000, // $10.00
          imageUrl: "https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?auto=format&fit=crop&q=80&w=1000",
          showtime: tomorrow,
        },
        {
          title: "Interstellar",
          description: "A team of explorers travel through a wormhole in space in an attempt to ensure humanity's survival.",
          ticketPrice: 1500, // $15.00
          imageUrl: "https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?auto=format&fit=crop&q=80&w=1000",
          showtime: tomorrow,
        }
      ]);
    }
  }
}

export const storage = new DatabaseStorage();
