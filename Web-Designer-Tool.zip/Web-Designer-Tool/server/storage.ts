import { db } from "./db";
import {
  services,
  bookings,
  bookingItems,
  type Service,
  type Booking,
  type CreateBookingRequest,
} from "@shared/schema";
import { eq, inArray } from "drizzle-orm";

export interface IStorage {
  getServices(): Promise<Service[]>;
  createBooking(booking: CreateBookingRequest): Promise<Booking>;
  seedServices(): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getServices(): Promise<Service[]> {
    return await db.select().from(services).orderBy(services.price);
  }

  async createBooking(req: CreateBookingRequest): Promise<Booking> {
    // Calculate total amount from services to ensure accuracy
    const selectedServices = await db
      .select()
      .from(services)
      .where(inArray(services.id, req.serviceIds));

    const totalAmount = selectedServices.reduce((sum, s) => sum + s.price, 0);

    // Create the booking
    const [booking] = await db
      .insert(bookings)
      .values({
        customerName: req.customerName,
        customerEmail: req.customerEmail,
        customerPhone: req.customerPhone,
        eventDate: new Date(req.eventDate),
        totalAmount: totalAmount,
        status: "confirmed", // Auto-confirm for this demo
      })
      .returning();

    // Create booking items links
    if (req.serviceIds.length > 0) {
      await db.insert(bookingItems).values(
        selectedServices.map((s) => ({
          bookingId: booking.id,
          serviceId: s.id,
          priceAtBooking: s.price,
        }))
      );
    }

    return booking;
  }

  async seedServices(): Promise<void> {
    const count = await db.select().from(services);
    if (count.length === 0) {
      await db.insert(services).values([
        {
          name: "Individual Portrait Session",
          description: "1-hour session, professional editing, 10 digital photos.",
          price: 15000, // $150.00
          category: "Portrait",
          imageUrl: "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?auto=format&fit=crop&q=80&w=1000",
        },
        {
          name: "Wedding Photography Package",
          description: "Full day coverage (8 hours), 300+ edited photos, online gallery.",
          price: 120000, // $1200.00
          category: "Wedding",
          imageUrl: "https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&q=80&w=1000",
        },
        {
          name: "Event Coverage",
          description: "Corporate or private events, per hour rate (min 2 hours).",
          price: 10000, // $100.00
          category: "Event",
          imageUrl: "https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&q=80&w=1000",
        },
        {
          name: "Product Photography",
          description: "High-quality product shots for e-commerce (5 products).",
          price: 25000, // $250.00
          category: "Commercial",
          imageUrl: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&q=80&w=1000",
        },
        {
          name: "Family Photo Shoot",
          description: "Outdoor or studio session for up to 5 family members.",
          price: 20000, // $200.00
          category: "Portrait",
          imageUrl: "https://images.unsplash.com/photo-1511895426328-dc8714191300?auto=format&fit=crop&q=80&w=1000",
        },
      ]);
    }
  }
}

export const storage = new DatabaseStorage();
