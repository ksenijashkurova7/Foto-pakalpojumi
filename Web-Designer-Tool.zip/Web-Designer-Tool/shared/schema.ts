import { pgTable, text, serial, integer, timestamp, boolean, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { sql } from "drizzle-orm";

// Movie Definition
export const movies = pgTable("movies", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  ticketPrice: integer("ticket_price").notNull(), // stored in cents
  imageUrl: text("image_url").notNull(),
  showtime: timestamp("showtime").notNull(),
});

// Ticket Reservation Definition
export const reservations = pgTable("reservations", {
  id: serial("id").primaryKey(),
  movieId: integer("movie_id").notNull().references(() => movies.id),
  customerName: text("customer_name").notNull(),
  customerEmail: text("customer_email").notNull(),
  ticketsCount: integer("tickets_count").notNull(),
  totalAmount: integer("total_amount").notNull(), // stored in cents
  discountApplied: boolean("discount_applied").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// Original tables for Photo Services
export const services = pgTable("services", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  price: integer("price").notNull(),
  category: text("category").notNull(),
  imageUrl: text("image_url").notNull(),
});

export const bookings = pgTable("bookings", {
  id: serial("id").primaryKey(),
  customerName: text("customer_name").notNull(),
  customerEmail: text("customer_email").notNull(),
  customerPhone: text("customer_phone"),
  eventDate: timestamp("event_date").notNull(),
  totalAmount: integer("total_amount").notNull(),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const bookingItems = pgTable("booking_items", {
  id: serial("id").primaryKey(),
  bookingId: integer("booking_id").notNull().references(() => bookings.id),
  serviceId: integer("service_id").notNull().references(() => services.id),
  priceAtBooking: integer("price_at_booking").notNull(),
});

// Schemas
export const insertBookingSchema = createInsertSchema(bookings).omit({ 
  id: true, 
  createdAt: true, 
  status: true,
  totalAmount: true 
});

export const createBookingSchema = insertBookingSchema.extend({
  serviceIds: z.array(z.number()).min(1, "Please select at least one service"),
  eventDate: z.coerce.date(),
});

export const insertReservationSchema = createInsertSchema(reservations).omit({ 
  id: true, 
  createdAt: true, 
  totalAmount: true,
  discountApplied: true 
});

export const createReservationSchema = insertReservationSchema.extend({
  ticketsCount: z.coerce.number().min(1, "At least 1 ticket required"),
});

export type Movie = typeof movies.$inferSelect;
export type Reservation = typeof reservations.$inferSelect;
export type CreateReservationRequest = z.infer<typeof createReservationSchema>;
export type InsertBooking = z.infer<typeof insertBookingSchema>;
export type CreateBookingRequest = z.infer<typeof createBookingSchema>;
export type Service = typeof services.$inferSelect;
export type Booking = typeof bookings.$inferSelect;
