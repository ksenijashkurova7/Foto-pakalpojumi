import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Service Definition
export const services = pgTable("services", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  price: integer("price").notNull(), // stored in cents
  category: text("category").notNull(), // e.g., "studio", "outdoor", "event"
  imageUrl: text("image_url").notNull(),
});

// Booking Definition
export const bookings = pgTable("bookings", {
  id: serial("id").primaryKey(),
  customerName: text("customer_name").notNull(),
  customerEmail: text("customer_email").notNull(),
  customerPhone: text("customer_phone"),
  eventDate: timestamp("event_date").notNull(),
  totalAmount: integer("total_amount").notNull(), // stored in cents
  status: text("status").notNull().default("pending"), // pending, confirmed, completed, cancelled
  createdAt: timestamp("created_at").defaultNow(),
});

// Join table for Bookings <-> Services (Many-to-Many)
// Alternatively, for simplicity in this specific task, we can store selected services as a JSON array in bookings,
// but a normalized approach is better. Let's use a simple JSON column for selected service IDs/Snapshots to keep it easy for the "school project" feel but robust enough.
// Actually, let's just do a jsonb column in bookings for the selected items to keep it simple and effective for this scope.
// Wait, better to be relational if possible, but JSONB is fine for "snapshotting" the service state at time of booking.
// Let's add a JSONB column to bookings for "items".

export const bookingItems = pgTable("booking_items", {
  id: serial("id").primaryKey(),
  bookingId: integer("booking_id").notNull().references(() => bookings.id),
  serviceId: integer("service_id").notNull().references(() => services.id),
  priceAtBooking: integer("price_at_booking").notNull(),
});

// Schemas
export const insertBookingSchema = createInsertSchema(bookings).omit({ 
  id: true, 
  createdAt: true, 
  status: true,
  totalAmount: true // Calculated on backend for security, or trusted from frontend for this specific "calculator" task? 
                    // Let's trust frontend for the "calculator" aspect visualization, but backend should validate.
                    // Actually, for the task "calculate total", frontend doing it is key.
});

// We need a schema that includes the service IDs being booked
export const createBookingSchema = insertBookingSchema.extend({
  serviceIds: z.array(z.number()).min(1, "Please select at least one service"),
  eventDate: z.coerce.date(), // Ensure date string is converted
});

export type Service = typeof services.$inferSelect;
export type Booking = typeof bookings.$inferSelect;
export type CreateBookingRequest = z.infer<typeof createBookingSchema>;
