## Packages
framer-motion | For smooth animations and page transitions
lucide-react | For beautiful icons (camera, users, etc.)
date-fns | For date formatting and handling

## Notes
- Tailwind Config: Extend fontFamily with 'Playfair Display' (serif) and 'Lato' (sans) for that premium portfolio look.
- Images: Using Unsplash for high-quality photography placeholders.
