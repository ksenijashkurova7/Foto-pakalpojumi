import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type CreateBookingRequest } from "@shared/routes"; // Assuming these are exported from routes
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";

// ============================================
// Service Hooks
// ============================================

export function useServices() {
  return useQuery({
    queryKey: [api.services.list.path],
    queryFn: async () => {
      const res = await fetch(api.services.list.path);
      if (!res.ok) throw new Error("Failed to fetch services");
      return api.services.list.responses[200].parse(await res.json());
    },
    // Seed initial data if API is empty/failing for demo purposes
    initialData: [
      { id: 1, name: "Portrait Session", description: "1-hour professional portrait session in studio or outdoors.", price: 15000, category: "studio", imageUrl: "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?auto=format&fit=crop&q=80&w=800" },
      { id: 2, name: "Wedding Package", description: "Full day coverage (8 hours), 2 photographers, digital album.", price: 120000, category: "event", imageUrl: "https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&q=80&w=800" },
      { id: 3, name: "Product Photography", description: "High-quality product shots for e-commerce. Up to 10 items.", price: 30000, category: "commercial", imageUrl: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&q=80&w=800" },
      { id: 4, name: "Family Gathering", description: "2-hour lifestyle session for families up to 6 people.", price: 25000, category: "outdoor", imageUrl: "https://images.unsplash.com/photo-1511895426328-dc8714191300?auto=format&fit=crop&q=80&w=800" },
      { id: 5, name: "Event Coverage", description: "Hourly coverage for corporate events or parties.", price: 10000, category: "event", imageUrl: "https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&q=80&w=800" },
      { id: 6, name: "Headshots", description: "Express 30-min session for professional LinkedIn profiles.", price: 8000, category: "studio", imageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=800" },
    ]
  });
}

// ============================================
// Booking Hooks
// ============================================

export function useCreateBooking() {
  const { toast } = useToast();
  
  return useMutation({
    mutationFn: async (data: CreateBookingRequest) => {
      // Ensure data is properly formatted for the schema
      const formattedData = {
        ...data,
        eventDate: new Date(data.eventDate), // Ensure Date object
      };

      const res = await fetch(api.bookings.create.path, {
        method: api.bookings.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formattedData),
      });

      if (!res.ok) {
        if (res.status === 400) {
          const error = await res.json();
          throw new Error(error.message || "Validation failed");
        }
        throw new Error("Failed to create booking");
      }
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Booking Request Sent",
        description: "We'll be in touch shortly to confirm your session.",
      });
    },
    onError: (error) => {
      toast({
        title: "Booking Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}
