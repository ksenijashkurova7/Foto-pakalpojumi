import { useState } from "react";
import { motion } from "framer-motion";
import { Camera, Aperture, Clock, Award } from "lucide-react";
import { useServices, useCreateBooking } from "@/hooks/use-services";
import { ServiceCard } from "@/components/ServiceCard";
import { BookingSummary } from "@/components/BookingSummary";
import { BookingForm } from "@/components/BookingForm";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";

export default function Home() {
  const { data: services, isLoading } = useServices();
  const createBooking = useCreateBooking();
  const { toast } = useToast();
  
  const [selectedServiceIds, setSelectedServiceIds] = useState<number[]>([]);
  const [isBookingModalOpen, setIsBookingModalOpen] = useState(false);

  // Toggle service selection
  const handleToggleService = (id: number) => {
    setSelectedServiceIds(prev => 
      prev.includes(id) 
        ? prev.filter(sId => sId !== id)
        : [...prev, id]
    );
  };

  const selectedServices = services?.filter(s => selectedServiceIds.includes(s.id)) || [];
  const totalAmount = selectedServices.reduce((sum, s) => sum + s.price, 0);

  const handleBookingSubmit = async (data: any) => {
    try {
      await createBooking.mutateAsync({
        ...data,
        serviceIds: selectedServiceIds,
        // The backend schema requires serviceIds array
      });
      setIsBookingModalOpen(false);
      setSelectedServiceIds([]); // Reset selection
    } catch (error) {
      // Error handling is managed by the mutation hook
      console.error(error);
    }
  };

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    show: { y: 0, opacity: 1 }
  };

  return (
    <div className="min-h-screen pb-32">
      {/* Hero Section */}
      <section className="relative h-[80vh] flex items-center justify-center overflow-hidden">
        {/* Unsplash hero image: professional camera photographer */}
        <div 
          className="absolute inset-0 z-0 bg-cover bg-center bg-no-repeat"
          style={{ 
            backgroundImage: `url('https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?auto=format&fit=crop&q=80&w=2000')`,
            backgroundPosition: "center 30%"
          }}
        >
          <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px]" />
        </div>

        <div className="relative z-10 text-center text-white px-4 max-w-4xl mx-auto">
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <h1 className="font-serif text-5xl md:text-7xl lg:text-8xl font-bold mb-6 tracking-tight">
              Capture the <span className="text-accent italic">Moment</span>
            </h1>
            <p className="font-sans text-lg md:text-xl text-white/90 max-w-2xl mx-auto leading-relaxed">
              Professional photography services tailored to your unique story. 
              Select your package below and let us handle the rest.
            </p>
          </motion.div>
        </div>

        {/* Scroll Indicator */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5, duration: 1 }}
          className="absolute bottom-10 left-1/2 -translate-x-1/2 text-white/70 flex flex-col items-center gap-2"
        >
          <span className="text-xs uppercase tracking-widest">Scroll to Explore</span>
          <div className="w-[1px] h-12 bg-gradient-to-b from-white to-transparent" />
        </motion.div>
      </section>

      {/* Features Banner */}
      <div className="bg-secondary/50 py-12 border-y border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="flex flex-col items-center text-center gap-2">
              <Camera className="w-8 h-8 text-accent" strokeWidth={1.5} />
              <h3 className="font-serif font-bold">High Resolution</h3>
            </div>
            <div className="flex flex-col items-center text-center gap-2">
              <Aperture className="w-8 h-8 text-accent" strokeWidth={1.5} />
              <h3 className="font-serif font-bold">Pro Editing</h3>
            </div>
            <div className="flex flex-col items-center text-center gap-2">
              <Clock className="w-8 h-8 text-accent" strokeWidth={1.5} />
              <h3 className="font-serif font-bold">Fast Delivery</h3>
            </div>
            <div className="flex flex-col items-center text-center gap-2">
              <Award className="w-8 h-8 text-accent" strokeWidth={1.5} />
              <h3 className="font-serif font-bold">Satisfaction</h3>
            </div>
          </div>
        </div>
      </div>

      {/* Services Grid */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-12 text-center">
          <h2 className="font-serif text-4xl md:text-5xl font-bold mb-4 text-primary">Our Services</h2>
          <div className="w-24 h-1 bg-accent mx-auto" />
          <p className="mt-4 text-muted-foreground max-w-xl mx-auto">
            Choose from our curated selection of professional photography packages.
            Select multiple services to create your custom bundle.
          </p>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="space-y-4">
                <Skeleton className="aspect-[4/3] w-full rounded-xl" />
                <Skeleton className="h-4 w-2/3" />
                <Skeleton className="h-4 w-1/2" />
              </div>
            ))}
          </div>
        ) : (
          <motion.div 
            variants={containerVariants}
            initial="hidden"
            animate="show"
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8"
          >
            {services?.map((service) => (
              <motion.div key={service.id} variants={itemVariants}>
                <ServiceCard
                  service={service}
                  isSelected={selectedServiceIds.includes(service.id)}
                  onToggle={handleToggleService}
                />
              </motion.div>
            ))}
          </motion.div>
        )}
      </section>

      {/* Booking Summary Floating Bar */}
      <BookingSummary
        selectedServices={selectedServices}
        onCheckout={() => setIsBookingModalOpen(true)}
      />

      {/* Booking Form Modal */}
      <BookingForm
        open={isBookingModalOpen}
        onOpenChange={setIsBookingModalOpen}
        onSubmit={handleBookingSubmit}
        isSubmitting={createBooking.isPending}
        totalAmount={totalAmount}
      />
    </div>
  );
}
