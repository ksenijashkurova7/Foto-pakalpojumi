import { motion, AnimatePresence } from "framer-motion";
import { ArrowRight, ShoppingBag } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { Service } from "@shared/schema";

interface BookingSummaryProps {
  selectedServices: Service[];
  onCheckout: () => void;
}

export function BookingSummary({ selectedServices, onCheckout }: BookingSummaryProps) {
  const totalAmount = selectedServices.reduce((sum, service) => sum + service.price, 0);
  
  const formattedTotal = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
  }).format(totalAmount / 100);

  if (selectedServices.length === 0) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: 100, opacity: 0 }}
        className="fixed bottom-0 left-0 right-0 z-50 p-4 md:p-6 bg-gradient-to-t from-background via-background to-transparent pointer-events-none"
      >
        <div className="max-w-4xl mx-auto pointer-events-auto">
          <div className="bg-primary text-primary-foreground rounded-full shadow-2xl p-2 pl-6 pr-2 flex items-center justify-between backdrop-blur-md bg-primary/95">
            <div className="flex items-center gap-4">
              <div className="bg-white/10 rounded-full p-2">
                <ShoppingBag className="w-5 h-5" />
              </div>
              <div className="flex flex-col md:flex-row md:items-baseline md:gap-2">
                <span className="text-sm font-medium opacity-80">
                  {selectedServices.length} {selectedServices.length === 1 ? 'service' : 'services'} selected
                </span>
                <span className="text-lg font-serif font-bold">
                  Total: {formattedTotal}
                </span>
              </div>
            </div>

            <Button 
              onClick={onCheckout}
              size="lg"
              className="rounded-full px-8 font-semibold bg-white text-black hover:bg-gray-200 transition-colors shadow-none"
            >
              Continue <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
