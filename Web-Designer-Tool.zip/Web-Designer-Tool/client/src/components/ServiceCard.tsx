import { motion } from "framer-motion";
import { Check } from "lucide-react";
import { cn } from "@/lib/utils";
import type { Service } from "@shared/schema";

interface ServiceCardProps {
  service: Service;
  isSelected: boolean;
  onToggle: (id: number) => void;
}

export function ServiceCard({ service, isSelected, onToggle }: ServiceCardProps) {
  // Format price from cents to display format
  const formattedPrice = new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
  }).format(service.price / 100);

  return (
    <motion.div
      whileHover={{ y: -5 }}
      className={cn(
        "group relative overflow-hidden rounded-xl border transition-all duration-300 cursor-pointer bg-card",
        isSelected 
          ? "border-primary ring-1 ring-primary shadow-lg" 
          : "border-border hover:border-primary/50 hover:shadow-md"
      )}
      onClick={() => onToggle(service.id)}
    >
      {/* Selection Indicator Overlay */}
      <div className={cn(
        "absolute top-3 right-3 z-20 h-8 w-8 rounded-full flex items-center justify-center transition-all duration-200",
        isSelected ? "bg-primary text-white scale-100" : "bg-white/80 text-transparent scale-90 opacity-0 group-hover:opacity-100"
      )}>
        <Check className="h-5 w-5" strokeWidth={3} />
      </div>

      <div className="aspect-[4/3] overflow-hidden relative">
        <div className={cn(
          "absolute inset-0 bg-primary/10 transition-opacity duration-300 z-10",
          isSelected ? "opacity-20" : "opacity-0 group-hover:opacity-10"
        )} />
        {/* Using the service image URL */}
        <img 
          src={service.imageUrl} 
          alt={service.name}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
      </div>

      <div className="p-5 space-y-3">
        <div className="flex justify-between items-start">
          <div>
            <span className="text-xs font-bold tracking-wider text-accent uppercase mb-1 block">
              {service.category}
            </span>
            <h3 className="font-serif text-xl font-semibold leading-tight group-hover:text-primary transition-colors">
              {service.name}
            </h3>
          </div>
          <p className="font-sans font-bold text-lg text-primary">
            {formattedPrice}
          </p>
        </div>
        
        <p className="text-muted-foreground text-sm line-clamp-2">
          {service.description}
        </p>
      </div>
    </motion.div>
  );
}
